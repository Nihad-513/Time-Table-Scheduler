import GA.assets.Attributes as att

num_hours = 6
# subs = att.sub3
day1 = ['h1','h2','h3','h4','h5','h6']
day2 = ['h1','h2','h3','h4','h5','h6']
day3 = ['h1','h2','h3','h4','h5','h6']
day4 = ['h1','h2','h3','h4','h5','h6']
day5 = ['h1','h2','h3','h4','h5','h6']
timtable  = [day1, day2, day3, day4, day5]
         

generated_sem3 =[[]]
generated_sem5 =[[]]

